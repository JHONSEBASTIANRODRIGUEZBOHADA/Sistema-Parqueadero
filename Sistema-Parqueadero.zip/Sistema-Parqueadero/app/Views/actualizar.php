<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Actualizar</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">

</head>

<body>
    <style>
        body {
            background-color: royalblue;
        }
    </style>
    <div class="container"><br> <br>
        <div class="container-fluid">
            <h1>Actualizar datos</h1>
            <form action="<?= base_url('actuallizar'); ?>" method="POST">
                <div class="form-group">
                    <input type="number" hidden name="usuId" value="<?= $paciente['usuId'] ?>">
                    <label>Tipo Documento</label>
                    <input readonly type="text" class="form-control" id="usuTipoDocumento" name="usuTipoDocumento"
                        value="<?= $paciente['usuTipoDocumento'] ?>">

                </div>
                <div class="form-group">
                    <label>Documento</label>
                    <input readonly type="text" class="form-control" id="usuDocumento" name="usuDocumento"
                        value="<?= $paciente['usuDocumento'] ?>">

                </div>
                <div class="form-group">
                    <label>Nombre</label>
                    <input readonly type="text" class="form-control" id="usuNombre" name="usuNombre"
                        value="<?= $paciente['usuNombre'] ?>">
                </div>
                <div class="form-group">
                    <label>Apellido</label>
                    <input readonly type="text" class="form-control" id="usuApellido" name="usuApellido"
                        value="<?= $paciente['usuApellido'] ?>">
                </div>

                <div class="form-group">
                    <label>Telefono</label>
                    <input type="number" class="form-control" id="usuTelefono" name="usuTelefono"
                        value="<?= $paciente['usuTelefono'] ?>">
                </div>

                <div class="form-group">
                    <label>Direccion</label>
                    <input type="text" class="form-control" id="usuDireccion" name="usuDireccion"
                        value="<?= $paciente['usuDireccion'] ?>">
                </div>

                <div class="form-group">
                    <label>Servicio</label>
                    <?php if (!empty($paciente['usuServicio'])): ?>
                        <select id="usuServicio" name="usuServicio" class="form-control">
                            <option selected>
                                <?= $paciente['usuServicio'] ?>
                            </option>
                            <option>Consulta General</option>
                            <option>Control De Embarazo</option>
                            <option>Tratamiento Especializado</option>
                        </select>
                    <?php else: ?>
                        <input type="text" class="form-control" id="usuServicio" name="usuServicio"
                            value="<?= $paciente['usuServicio'] ?>">
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label>Doctor</label>
                    <?php if (!empty($paciente['usuDoctor'])): ?>
                        <select id="usuDoctor" name="usuDoctor" class="form-control">
                            <option selected>
                                <?= $paciente['usuDoctor'] ?>
                            </option>
                            <option>George Zapata</option>
                            <option>Omar Rodriguez</option>
                            <option>Jose Perez</option>
                        </select>
                    <?php else: ?>
                        <input type="text" class="form-control" id="usuDoctor" name="usuDoctor"
                            value="<?= $paciente['usuDoctor'] ?>">
                    <?php endif; ?>
                </div><br>

                <button type="submit" class="btn btn-warning">Actualizar</button>
                <button type="submit" class="btn btn-danger">Salir</button>
            </form>
        </div>
    </div>

</body>

</html>