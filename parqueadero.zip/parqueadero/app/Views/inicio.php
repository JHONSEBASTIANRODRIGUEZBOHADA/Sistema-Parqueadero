<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="css/style.css" rel="stylesheet">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.9.4/css/bulma.min.css">
    <title>Parqueadero</title>
</head>
<body>
	<style>
		body {
		background-color: royalblue;
    	}
  </style>
	<section class="hero is-primary">
        <div class="hero-body">
            <p class="title">PARQUEADERO</p>
            <p class="subtitle">Bienvenido</p>
        </div>
    </section>
    <div class="container"><br> <br>
		<div class="container-fluid">
			<table class="table table-striped table-gray">
				<thead>
				<tr>
						<th scope="col">Id</th>
						<th scope="col">Tipo Documento</th>
						<th scope="col">N°Documento</th>
						<th scope="col">Nombre</th>
						<th scope="col">Apellido</th>
						<th scope="col">Telefono</th>
					</tr>
				</thead>
				<tbody>
				<?php foreach ($pacientes as $pac) : ?>
						<tr>
							<th scope="row"> <?= $pac['conId'] ?></th>
							<td><?= $pac['conTipoDocumento'] ?></td>
							<td><?= $pac['conDocumento'] ?></td>
							<td><?= $pac['conNombre'] ?></td>
							<td><?= $pac['conApellido'] ?></td>
							<td><?= $pac['conTelefono'] ?></td>
							<td><a href="<?php echo base_url('editar/' . $pac['conId']) ?>"><button type="button" class="btn btn-success">Actualizar</button></a><a href="<?php echo base_url('eliminar/' . $pac['conId']) ?>"><button type="button" class="btn btn-danger">Eliminar</button></a></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
			<div>
				<a href="<?php echo base_url('agregar'); ?>"> <button type="button" class="btn btn-warning">Agendar</button></a>
			</div><br>
		</div>
	</div>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js" integrity="sha384-W8fXfP3gkOKtndU4JGtKDvXbO53Wy8SZCQHczT5FMiiqmQfUpWbYdTil/SxwZgAN" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.min.js" integrity="sha384-skAcpIdS7UcVUC05LJ9Dxay8AXcDYfBJqt1CJ85S/CFujBsIzCIv+l9liuYLaMQ/" crossorigin="anonymous"></script>
</body>
</html>