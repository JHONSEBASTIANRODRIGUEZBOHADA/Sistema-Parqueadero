<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Registre conductor</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.9.4/css/bulma.min.css">
</head>

<body>
  <style>
    body {
      background-color: royalblue;
    }
  </style>
  <section class="hero is-primary">
        <div class="hero-body">
            <p class="title">PARQUEADERO</p>
            <p class="subtitle">Registre el conductor aqui</p>
        </div>
    </section><br>
  <div class="container">
    <form action="insertar" method="POST">
      <div class="form-row">
        <div class="form-group col-md-4">
          <label>Tipo Documento</label>
          <select id="conTipoDocumento" name="conTipoDocumento" class="form-control">
            <option selected>Elija...</option>
            <option>C.C</option>
            <option>T.I</option>
          </select>
        </div>
        <div class="form-group col-md-6">
          <label>Documento</label>
          <input type="number" class="form-control" id="conDocumento" name="conDocumento">
        </div>
        <div class="form-group col-md-6">
          <label>Nombre</label>
          <input type="text" class="form-control" id="conNombre" name="conNombre">
        </div>
      </div>
      <div class="form-row">
        <div class="form-group col-md-6">
          <label>Apellido</label>
          <input type="text" class="form-control" id="conApellido" name="conApellido">
        </div>
        <div class="form-group col-md-6">
          <label>Telefono</label>
          <input type="number" class="form-control" id="conTelefono" name="conTelefono">
        </div>
      </div>
      <button type="submit" class="btn btn-warning">Registrar</button>
      <button type="submit" class="btn btn-danger">Salir</button>
  </div>

  </form>
  </div>

  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
</body>

</html>