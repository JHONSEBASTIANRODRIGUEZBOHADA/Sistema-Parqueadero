<?php 
namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\mod_Usuario;

class Cont_Usuario extends Controller{

  public function index(){
    $pac = new mod_Usuario();
    $data['pacientes']=$pac->findAll();
    return view('inicio',$data);
  }

  public function registrarCita(){
    return view('agregar');
  }

  public function insertar(){
    $pac = new mod_Usuario();

    $dato=[
      'conTipoDocumento' => $_POST['conTipoDocumento'],
      'conDocumento' => $_POST['conDocumento'],
      'conNombre' => $_POST['conNombre'],
      'conApellido' => $_POST['conApellido'],
      'conTelefono' => $_POST['conTelefono']
    ];
    $pac->insert($dato);
    return redirect()->to(base_url());
  }

  public function eliminar($conId=null){
    $pac = new mod_Usuario();
    $pac->delete($conId);
    return redirect()->to(base_url());
  }

  public function editar($conId=null){
    $pac = new mod_Usuario();
    $registro['paciente']=$pac->find($conId);
    return view('actualizar',$registro);
  }

  public function actuallizar(){
    $pac = new mod_Usuario();
    $usuId = $_POST['conId'];

    $dato=[
      'conTipoDocumento' => $_POST['conTipoDocumento'],
      'conDocumento' => $_POST['conDocumento'],
      'conNombre' => $_POST['conNombre'],
      'conApellido' => $_POST['conApellido'],
      'conTelefono' => $_POST['conTelefono']
    ];
    $pac->update($usuId,$dato);
    return redirect()->to(base_url());
  }
}