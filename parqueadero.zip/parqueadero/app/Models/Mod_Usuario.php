<?php 
namespace App\Models;

use CodeIgniter\Model;

class Mod_Usuario extends Model{
  protected $table ='conductor';
  protected $primaryKey = 'conId';
  protected $allowedFields=['conTipoDocumento','conDocumento','conNombre','conApellido','conTelefono'];
}
